INTERACTION TWIN / NEWTON CPU CONTACT STARTER

Three generated components from the curated Interaction Twin library.
Actual Newton 1.7 / Warp 1.17 CPU release + contact test.

RUN (Python 3.12 on macOS Apple Silicon, Linux or Windows):
  python3.12 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  python run_experiment.py run --input input.json --output replay.json

The engine runner is self contained; it reads collision hulls from input.json.
native/ holds the unchanged generated appearance assets for a renderer.
manifest.json pins every file, including original native source paths/hashes.

ASSUMPTIONS / LIMITS
Sizes, density, friction, restitution and release pose are authored assumptions.
Metric scale was not measured. Convex proxies fill concavities.
No robot grasp, insertion, learned policy or physical accuracy is validated.
This is not Isaac Sim and does not certify the twins simulation ready.

PRIMARY DOCUMENTATION
https://developer.nvidia.com/newton-physics
https://newton-physics.github.io/newton/1.7.0/guide/installation.html
https://docs.isaacsim.omniverse.nvidia.com/latest/installation/requirements.html
