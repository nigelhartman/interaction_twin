INTERACTION TWIN — AUTHORED ROBOT TASK STARTER

Extract completely. Run: python3 -I -S preview_server.py --port 0
Open the printed localhost URL; Python3.10+ and no packages or internet are required.
The browser uses exact included native models and an authored joint-limited kinematic robot.
Use the browser JSON editor for task variations; the included source/kit bindings stay fixed.
On-disk files are integrity-bound. A developer fork needs a fresh manifest.
For agent edits: validate_robot_task(edited_task), then export_robot_task_bundle(edited_task).
Read the new declared MCP ZIP resource and verify its hash before extraction.
No physical scale, collision/contact validation,
robot training, hardware control, hosted model calls or approved execution is included.
Original source/program provenance pointers are retained; only files in bundle-manifest.json
are included. No owner login, uploads, private feedback or credentials are packaged.
Keep the vendored Three.js LICENSE with its source. Original workbench code is supplied
as a reusable project starter. Nothing is deployed by this archive.
